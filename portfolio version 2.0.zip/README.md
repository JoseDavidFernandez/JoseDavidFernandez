# Hi, I'm Jose David! 👋

## 🚀 About Me
Bienvenidos a mi portafolio personal, soy un desarrollador de aplicaciones web y marketing digital con experiencia en HTML, CSS, JavaScript, Bootstrap y PHP, así como en los CMS WordPress y Shopify. En esta página encontrarás algunos de mis proyectos personales que he creado de forma autodidacta, incluyendo aplicaciones web, páginas estáticas, e-commerce y proyectos de marketing digital. También puedes explorar mi página de GitHub para ver más de mis proyectos y contribuciones a proyectos de código abierto.

## 🔗 Links
[![portfolio](https://img.shields.io/badge/my_portfolio-000?style=for-the-badge&logo=ko-fi&logoColor=white)](https://josedavidfernandezcomino.com)
[![linkedin](https://img.shields.io/badge/linkedin-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/josedavidfernándezcomino/)
[![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)](https://github.com/JoseDavidFernandez)

![Logo](https://user-images.githubusercontent.com/107296373/236514091-5f8a9760-35df-46fb-b922-f046bcbef5af.png)



